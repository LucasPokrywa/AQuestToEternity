using UnityEngine;

public class PlayerRobotLink : MonoBehaviour
{
    [Header("R�f�rence au script du Robot")]
    // La r�f�rence vers le script d'animation qu'on a cr�� tout � l'heure
    public RobotAnimation robotAnimScript;

    private Vector3 lastPosition;

    void Start()
    {
        // On m�morise la position de d�part
        lastPosition = transform.position;
    }

    void Update()
    {
        // 1. Calcul de la distance parcourue depuis la derni�re frame
        float distanceMoved = Vector3.Distance(transform.position, lastPosition);

        // 2. Calcul de la vitesse (distance / temps)
        float currentSpeed = distanceMoved / Time.deltaTime;

        // 3. D�termination de l'�tat (vitesse tr�s faible = � l'arr�t)
        // On utilise 0.05f pour avoir une petite marge de tol�rance
        bool playerIsStopped = currentSpeed < 0.05f;

        // 4. On transmet l'�tat au script du robot
        if (robotAnimScript != null)
        {
            robotAnimScript.isIdle = playerIsStopped;
        }

        // 5. On met � jour l'ancienne position pour la frame suivante
        lastPosition = transform.position;
    }
}