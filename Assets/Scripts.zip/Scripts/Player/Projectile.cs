using UnityEngine;

public class Projectile : MonoBehaviour
{
    public int damage = 1;

    void OnCollisionEnter(Collision collision)
    {
        // On v�rifie si l'objet touch� poss�de le script LizardAI
        LizardAI lizard = collision.gameObject.GetComponent<LizardAI>();

        if (lizard != null)
        {
            lizard.TakeDamage(damage);
        }

        // Optionnel : D�truire le missile apr�s l'impact
        Destroy(gameObject);
    }
}