using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class QuestManager : MonoBehaviour
{
    public static QuestManager Instance { get; private set; }

    private List<Quest> activeQuests = new();
    private List<QuestData> completedQuests = new();

    public event Action<Quest> OnQuestStarted;
    public event Action<Quest> OnQuestCompleted;
    public event Action<Quest, Objective> OnObjectiveUpdated;

    void Awake() => Instance = this;

    public bool TryStartQuest(QuestData data)
    {
        foreach (var prereq in data.prerequisites)
            if (!completedQuests.Contains(prereq)) return false;

        var quest = new Quest { data = data, status = QuestStatus.Active };
        quest.objectives = data.objectives.Select(o => new Objective { data = o }).ToList();
        activeQuests.Add(quest);
        OnQuestStarted?.Invoke(quest);
        return true;
    }

    public void ReportEvent(ObjectiveType type, string targetID, int amount = 1)
    {
        foreach (var quest in activeQuests.ToList())
        {
            quest.UpdateObjective(type, targetID, amount);
            if (quest.IsCompleted()) CompleteQuest(quest);
        }
    }

    public void ReportEvent(ObjectiveType type, GameObject target, int amount = 1)
    {
        string id = target.name.Replace("(Clone)", "").Trim();
        ReportEvent(type, id, amount);
    }

    private void CompleteQuest(Quest quest)
    {
        quest.status = QuestStatus.Completed;
        activeQuests.Remove(quest);
        completedQuests.Add(quest.data);
        OnQuestCompleted?.Invoke(quest);
    }
}