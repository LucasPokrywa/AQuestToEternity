using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class QuestManager : MonoBehaviour
{
    public static QuestManager Instance { get; private set; }

    private List<Quest> activeQuests = new();
    private List<QuestData> completedQuests = new();
    [Header("Toutes les quêtes du jeu")]
    public List<QuestData> allQuests;

    public event Action<Quest> OnQuestStarted;
    public event Action<Quest> OnQuestCompleted;
    public event Action<Quest, Objective> OnObjectiveUpdated;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
    private static void Bootstrap()
    {
        if (Instance != null) return;

        var prefab = Resources.Load<QuestManager>("QuestManager");
        if (prefab == null)
        {
            Debug.LogError("QuestManager prefab introuvable dans Resources/");
            return;
        }

        var instance = Instantiate(prefab);
        instance.name = "QuestManager";
    }

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject); 
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    void Start()
    {
        TryStartAvailableQuests(); 
    }

    public bool TryStartQuest(QuestData data)
    {
        foreach (var prereq in data.prerequisites)
            if (!completedQuests.Contains(prereq)) return false;

        var quest = new Quest { data = data, status = QuestStatus.Active };
        quest.objectives = data.objectives.Select(o => new Objective { data = o }).ToList();
        activeQuests.Add(quest);
        OnQuestStarted?.Invoke(quest);
        return true;
    }

    private void TryStartAvailableQuests()
    {
        foreach (var data in allQuests)
        {
            if (completedQuests.Contains(data)) continue;
            if (activeQuests.Any(q => q.data == data)) continue;

            TryStartQuest(data); 
        }
    }

    public void ReportEvent(ObjectiveType type, string targetID, int amount = 1)
    {
        foreach (var quest in activeQuests.ToList())
        {
            var updatedObjectives = quest.UpdateObjective(type, targetID, amount);

            foreach (var obj in updatedObjectives)
            {
                Debug.Log($"📈 [{quest.data.questName}] {obj.data.description} : {obj.currentAmount}/{obj.data.requiredAmount}");
                OnObjectiveUpdated?.Invoke(quest, obj);
            }

            if (quest.IsCompleted()) CompleteQuest(quest);
        }
    }

    public void ReportEvent(ObjectiveType type, GameObject target, int amount = 1)
    {
        string id = target.name.Replace("(Clone)", "").Trim();
        ReportEvent(type, id, amount);
    }

    private void CompleteQuest(Quest quest)
    {

        Debug.Log($"[Quest] Terminée : {quest.data.questName}");

        Debug.Log($"✅ Quête terminée : {quest.data.questName}");
        quest.status = QuestStatus.Completed;
        activeQuests.Remove(quest);
        completedQuests.Add(quest.data);
        OnQuestCompleted?.Invoke(quest);
        TryStartAvailableQuests();
    }


}